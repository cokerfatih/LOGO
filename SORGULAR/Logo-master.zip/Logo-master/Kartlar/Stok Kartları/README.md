|      |                    | 
|------|--------------------| 
| CARDTYPE | ANLAM          | 
| 1    | Ticari mal         | 
| 2    | Karma koli         | 
| 3    | Depozitolu mal     | 
| 4    | Sabit kıymet       | 
| 10   | Hammadde           | 
| 11   | Yarımamul          | 
| 12   | Mamul              | 
| 13   | Tükletim malı      | 
| 20   | M.sınıfı (genel)   | 
| 21   | M.sınıfı (tablolu) | 
| 22   | Firma dosyaları    | 
