# Muhasebe Fiş Hareketlerinden Yaşlandırma Raporu
Cari hareketler, ödeme planları ve borç kapama verileri olmadan muhasebe hareketleri üzerinden borç alacak yaşlandırma raporları

### Raporu Kullanırken
Raporu kullanırken değiştirmeniz gereken yerler;
- 141 nolu firma 01 nolu dönem kullanıldı
- 2 rapor var birisi borçlular birisi alacaklılar için. Borçluların hesap kodları 120. ile başlıyor, alacaklılar 32 ile başlıyor.



## Detaylı Excel Ekran Görüntüsü
### Sorgudan gelen detaylı veriler Pivot tablo ile özetlendiğinde
![](https://github.com/ugurozpinar/logosql/raw/master/Screenshots/borcyaslandirmapivot.png)


## Özet Ekran Görüntüsü
![](https://github.com/ugurozpinar/logosql/raw/master/Screenshots/borcyaslandirmaozet.png)
