ftp://download.logo.com.tr/Windows/TOOLS/A4_Raporlar/ adresinden alınan tasarım dosyaları
