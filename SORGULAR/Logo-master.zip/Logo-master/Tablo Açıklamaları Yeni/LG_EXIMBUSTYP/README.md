### LG_EXIMBUSTYP

## Alanlar

**Level**|**Product ID**|**Field Name**|**Field Type**|**Field Size**|**Field Offset**|**Türkçe Açıklama**|**Expression**
-----|-----|-----|-----|-----|-----|-----|-----
0|0|LOGICALREF|Longint|4|0|İthalat / İhracat Ticaret Cinsi Log. Ref.|Export / Import Business Typ Logical Reference
0|0|CODE|ZString|25|4|İthalat/İhracat İş Kodu|Import / Export Business Code
0|0|DEFINITION_|ZString|51|29|İthalat/İhracat İş Açıklaması|Import / Export Business Definition

## İlişkiler - Relations

**Level**|**Product ID**|**Resource ID**|**Special Code**|**Source Field**|**Destination Table**|**Destination Field**|**Relation Type**|**Extra Condition**
-----|-----|-----|-----|-----|-----|-----|-----|-----

## Indexler

**Level**|**Product ID**|**Index Name**|**Attributes**|**Segment No**|**Segment Field**|**Sense**
-----|-----|-----|-----|-----|-----|-----
0|0|Index1|Unique + Not Null|1|LOGICALREF|Ascending
0|0|Index2|Unique + Not Null|1|CODE|Ascending
