# Logo SQL
Logo Tiger Enterprise özel raporlar

### [Tiger 3, Tiger 3 Enterprise, Go 3 Veritabanı (Database)](tabloaciklamalari.md)
### [Lot ve Depo Bazında Stok Raporu](https://github.com/ugurozpinar/logosql/blob/master/lot_depo_rapor.sql "Logo Tiger Enterprise özel rapor - Lot ve Depo Bazında Stok")
### [Çekler Raporu](https://github.com/ugurozpinar/logosql/blob/master/cekler.sql "Logo Muhasebe Programı Çekler Raporu")
### [Muhasebe Fiş Hareketlerinden Yaşlandırma Raporu](borcyaslandirma.md)
### [Faturalar Satır Detaylı](https://github.com/ugurozpinar/Logo/tree/master/Faturalar%20Sat%C4%B1r%20Detayl%C4%B1 "Satır Bazında Fatura Detay İndirilecek KDV")


## Repo Hakkında
Repoya dahil olmasını istediğiniz raporlar olursa commit yapabilir ya da önerileriniz için [bana](https://facebook.com/ugurozpinar) mesaj atabilirsiniz.

Logo'da tablolar firma numaralarına göre değiştiğinden; sql'i çalıştırmadan önce firma numaralarını kendinize göre değiştiriniz



[logo tiger](https://github.com/ugurozpinar/logosql/ "logo tiger")
[logo programı](https://github.com/ugurozpinar/logosql/ "logo programı")
[logo muhasebe programı](https://github.com/ugurozpinar/logosql/ "logo muhasebe programı")
[logo go plus](https://github.com/ugurozpinar/logosql/ "logo go plus")
[logo destek](https://github.com/ugurozpinar/logosql/ "logo destek")
[logo go](https://github.com/ugurozpinar/logosql/ "logo go")
[logo go 3](https://github.com/ugurozpinar/logosql/ "logo go 3")
[tiger programı](https://github.com/ugurozpinar/logosql/ "tiger programı")
[tiger plus](https://github.com/ugurozpinar/logosql/ "tiger plus")
[logo start](https://github.com/ugurozpinar/logosql/ "logo start")
[logo tiger plus](https://github.com/ugurozpinar/logosql/ "logo tiger plus")
[logo tiger programı](https://github.com/ugurozpinar/logosql/ "logo tiger programı")
[tiger 3](https://github.com/ugurozpinar/logosql/ "tiger 3")
[tiger fiyatları](https://github.com/ugurozpinar/logosql/ "tiger fiyatları")
[logo tiger eğitimi](https://github.com/ugurozpinar/logosql/ "logo tiger eğitimi")
[logo muhasebe programı nasıl kullanılır](https://github.com/ugurozpinar/logosql/ "logo muhasebe programı nasıl kullanılır")
[logo muhasebe programı demo](https://github.com/ugurozpinar/logosql/ "logo muhasebe programı demo")
[logo fiyat listesi](https://github.com/ugurozpinar/logosql/ "logo fiyat listesi")
[logo go plus eğitim](https://github.com/ugurozpinar/logosql/ "logo go plus eğitim")
